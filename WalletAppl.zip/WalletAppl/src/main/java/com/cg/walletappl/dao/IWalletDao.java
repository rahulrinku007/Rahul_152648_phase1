package com.cg.walletappl.dao;

import java.util.TreeMap;

import com.cg.walletappl.bean.Customer;

public interface IWalletDao {

	TreeMap<String, Customer> getDetails();

	String addCustomer(Customer customer);

}
