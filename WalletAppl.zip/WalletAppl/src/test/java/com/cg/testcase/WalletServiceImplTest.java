
package com.cg.testcase;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.TreeMap;

import org.junit.Test;

import com.cg.walletappl.exception.BankException;
import com.cg.walletappl.bean.Customer;
import com.cg.walletappl.bean.Wallet;
import com.cg.walletappl.service.IWalletService;
import com.cg.walletappl.service.WalletServiceImpl;

public class WalletServiceImplTest {
	public static IWalletService iWalletService=new WalletServiceImpl();
    @Test
	public void addCustomerTestTrue() throws BankException
	{
		Customer customer1 = new Customer("8500409260","Rahul","Rahul@007","rahulpatnala007@gmail.com",new Wallet(),new TreeMap<LocalDateTime, String>());
		assertEquals("8500409260",iWalletService.addCustomer(customer1));
			
	}
    @Test(expected=BankException.class)
  	public void addCustomerTestFalse() throws BankException
  	{

  		Customer customer2 = new Customer("9515178739","Sandeep","Sandy@123","chsandeepcool@gmail.com",new Wallet(),new TreeMap<LocalDateTime, String>());
  		assertNotEquals("9515178739",iWalletService.addCustomer(customer2));
  		
  	}
	

	@Test
	public void initBalanceTest() throws BankException
	{
		Customer customer3 = new Customer("9652556174","Rahul","Rahul@007","rahulpatnala007@gmail.com",new Wallet(),new TreeMap<LocalDateTime, String>());
		iWalletService.addCustomer(customer3);
		assertEquals(BigDecimal.valueOf(0.0),customer3.getWallet().getBalance());
		
	}
	
	@Test
	public void depositMoneyTest() throws BankException
	{
		Customer customer4 = new Customer("8331811624","Sandeep","Sandy@123","chsandeepcool@gmail.com",new Wallet(),new TreeMap<LocalDateTime, String>());
		iWalletService.addCustomer(customer4);
		iWalletService.deposit(customer4, BigDecimal.valueOf(8500.00));
		Customer result = iWalletService.showBalance("8331811624", "Sandy@123");
		assertEquals(BigDecimal.valueOf(8500.00),result.getWallet().getBalance());
	}
	@Test(expected=BankException.class)
	public void withdrawMoneyTestTrue() throws BankException
	{
		Customer customer5 = new Customer("8500409260","Rahul","Rahul@007","rahulpatnala007@gmail.com",new Wallet(),new TreeMap<LocalDateTime, String>());
		iWalletService.addCustomer(customer5);
		iWalletService.deposit(customer5, BigDecimal.valueOf(8500.00));
		assertTrue(iWalletService.withDraw(customer5, BigDecimal.valueOf(3000.00)));
	}

	
	@Test(expected = BankException.class)
	public void withdrawMoneyTestFalse() throws BankException
	{
		Customer customer6 = new Customer("9515178739","Sandeep","Sandy@123","chsandeepcool@gmail.com",new Wallet(),new TreeMap<LocalDateTime, String>());
		iWalletService.addCustomer(customer6);
		iWalletService.deposit(customer6, BigDecimal.valueOf(8500.00));
		assertFalse(iWalletService.withDraw(customer6, BigDecimal.valueOf(9000.00)));
	}

}
